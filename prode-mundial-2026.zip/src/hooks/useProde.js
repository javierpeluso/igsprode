import { useState, useEffect } from 'react';
import {
  doc, setDoc, getDoc, onSnapshot, collection, getDocs
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { calcPoints, ALL_MATCHES } from '../data/fixture';
import { markResultUpdated } from './useNewResults';
import { pushResultEvent, pushJoinedEvent } from './useFeed';
import { recalcUserStats, recalcGlobalStats } from './useProfile';

// ── Firestore structure ──────────────────────────────────────────────────────
// /users/{userId}           → { displayName, email, photoURL }
// /predictions/{userId}     → { [matchId]: { home, away }, ... }  (doc plano)
// /results                  → doc('all') → { [matchId]: { home, away }, ... }
// /scores/{userId}          → { pts, exact, winner, played,
//                               displayName, email, photoURL }
// ────────────────────────────────────────────────────────────────────────────

async function recalcScore(userId, allResults) {
  const predSnap = await getDoc(doc(db, 'predictions', userId));
  const preds = predSnap.exists() ? predSnap.data() : {};

  let pts = 0, exact = 0, winner = 0, played = 0;
  ALL_MATCHES.forEach((m) => {
    const res = allResults[m.id];
    if (!res) return;
    played++;
    const p = calcPoints(preds[m.id], res);
    if (p === 3) { pts += 3; exact++; }
    else if (p === 1) { pts += 1; winner++; }
  });

  const userSnap = await getDoc(doc(db, 'users', userId));
  const ud = userSnap.exists() ? userSnap.data() : {};

  // Bonus campeón: +10 si acertó (solo cuando hay resultado oficial en /campeon_result/winner)
  const campeonResultSnap = await getDoc(doc(db, '_meta', 'campeonWinner'));
  const campeonWinner = campeonResultSnap.exists() ? campeonResultSnap.data().team : null;
  const campeonPredSnap = await getDoc(doc(db, 'campeon', userId));
  const campeonPred = campeonPredSnap.exists() ? campeonPredSnap.data().team : null;
  const campeonBonus = campeonWinner && campeonPred && campeonWinner === campeonPred ? 10 : 0;

  await setDoc(doc(db, 'scores', userId), {
    pts: pts + campeonBonus, exact, winner, played,
    campeonPred: campeonPred || '',
    campeonBonus,
    displayName: ud.displayName || '',
    email: ud.email || '',
    photoURL: ud.photoURL || '',
  });
}

export function usePredictions(userId) {
  const [predictions, setPredictions] = useState({});

  useEffect(() => {
    if (!userId) return;
    const unsub = onSnapshot(doc(db, 'predictions', userId), (snap) => {
      setPredictions(snap.exists() ? snap.data() : {});
    });
    return unsub;
  }, [userId]);

  const savePrediction = async (matchId, home, away) => {
    await setDoc(doc(db, 'predictions', userId), { [matchId]: { home, away } }, { merge: true });
    const snap = await getDoc(doc(db, 'results', 'all'));
    const allRes = snap.exists() ? snap.data() : {};
    await recalcScore(userId, allRes);
    await recalcUserStats(userId, allRes);
  };

  return { predictions, savePrediction };
}

export function useResults() {
  const [results, setResults] = useState({});

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'results', 'all'), (snap) => {
      setResults(snap.exists() ? snap.data() : {});
    });
    return unsub;
  }, []);

  const saveResult = async (matchId, home, away) => {
    await setDoc(doc(db, 'results', 'all'), { [matchId]: { home, away } }, { merge: true });
    const snap = await getDoc(doc(db, 'results', 'all'));
    const allResults = snap.exists() ? snap.data() : {};
    const usersSnap = await getDocs(collection(db, 'users'));
    await Promise.all(usersSnap.docs.map((u) => recalcScore(u.id, allResults)));
    await markResultUpdated();
    // Push feed events
    const matchObj = ALL_MATCHES.find(m => m.id === matchId);
    if (matchObj) await pushResultEvent(matchObj, home, away);
    // Recalc stats for all users
    await Promise.all(usersSnap.docs.map(u => recalcUserStats(u.id, allResults)));
    await recalcGlobalStats(allResults);
  };

  return { results, saveResult };
}

export function useRanking() {
  const [ranking, setRanking] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'scores'), (snap) => {
      const rows = snap.docs
        .map((d) => ({ uid: d.id, ...d.data() }))
        .sort((a, b) => b.pts - a.pts || b.exact - a.exact);
      setRanking(rows);
      setLoading(false);
    });
    return unsub;
  }, []);

  return { ranking, loading };
}

export async function registerUser(user) {
  // NO escribir en allowed_emails desde el cliente.
  // El admin agrega los emails desde el panel.

  const ref = doc(db, 'users', user.uid);
  const snap = await getDoc(ref);
  const isNew = !snap.exists();

  // Crear perfil si no existe
  if (isNew) {
    await setDoc(ref, {
      displayName: user.displayName,
      email: user.email,
      photoURL: user.photoURL || '',
    });
  }

  // Garantizar que scores siempre existe con valores iniciales
  // (usa merge para no pisar puntos existentes)
  const scoresRef = doc(db, 'scores', user.uid);
  const scoresSnap = await getDoc(scoresRef);
  if (!scoresSnap.exists()) {
    await setDoc(scoresRef, {
      pts: 0, exact: 0, winner: 0, played: 0,
      displayName: user.displayName,
      email: user.email,
      photoURL: user.photoURL || '',
    });
  }

  if (isNew) await pushJoinedEvent(user);
}
